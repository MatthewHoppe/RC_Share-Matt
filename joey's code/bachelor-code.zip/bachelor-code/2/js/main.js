$(document).ready(function(){

	$("#andiNext").on("click",function(){

		$("INSERT_CODE_HERE").toggleClass("INSERT_CODE_HERE");
		

	});
	$("#claireNext").on("click",function(){

		$("INSERT_CODE_HERE").toggleClass("INSERT_CODE_HERE");
		

	});
	$("#sharleenNext").on("click",function(){

		$("INSERT_CODE_HERE").toggleClass("INSERT_CODE_HERE");
		

	});


});