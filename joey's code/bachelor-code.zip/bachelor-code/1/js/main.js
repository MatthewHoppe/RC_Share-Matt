$(document).ready(function(){

	$("#finalRose").on("click",function(){

		$("INSERT_CODE_HERE").hide();
		$("INSERT_CODE_HERE").hide();

	});


});