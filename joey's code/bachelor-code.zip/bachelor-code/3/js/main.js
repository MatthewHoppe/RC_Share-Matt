$(document).ready(function(){

	$(".women").on("click",function(){

		INSERT_CODE_HERE($(this).hasClass("rose")){
			$("INSERT_CODE_HERE").toggleClass("hidden");
		}INSERT_CODE_HERE{
			alert("Wrong!");
		}
		
		

	});

});